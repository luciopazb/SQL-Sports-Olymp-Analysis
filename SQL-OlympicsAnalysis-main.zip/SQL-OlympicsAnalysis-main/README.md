# SQL-OlympicsAnalysis
Encontre una base de datos de las olimpiadas y me resulto interesante hacerme algunas preguntas y responderlas con los siguientes querys
